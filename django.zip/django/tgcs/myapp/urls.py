from django.contrib import admin
from django.urls import path
from myapp import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.index,name='myapp'),
    path('register', views.register,name='register'),
    path('login', views.login_user ,name='login'),
    path('logout', views.logout_user ,name='logout'),
    path('reset_password', views.reset_password ,name='resetpassword'),

    path('reset_pass',auth_views.PasswordResetView.as_view(),name="reset_pass"),
    path('reset_pass_sent',auth_views.PasswordResetDoneView.as_view(),name="pass_reset_sent"),
    path('reset/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(),name="pass_reset_confirm"),
    path('reset_pass_complete',auth_views.PasswordResetCompleteView.as_view(),name="pass_reset_complete"),
     
    # path('services', views.services,name='services'),
    # path('contacts', views.contacts,name='contacts'),
]


from django.shortcuts import render,HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.core.mail import send_mail
from .helper import send_forget_password_mail


# Create your views here.
def index(request):
    return render(request,"main.html")

def register(request):
    if request.method=='POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        username = request.POST.get('username')

        if User.objects.filter(email=email).exists():
            messages.warning(request,"email is already exist")
            return redirect('register')
        else: 
            user = User(email=email,password=password,first_name=fname,last_name=lname,username=username)
            user.set_password(password)
            user.save()
            subject = 'about registration'
            message = f'Hi {username},You has been registered successfully on usermanagement blog'
            email_from = 'yogigujjar26@gmail.com'
            rec_list = [email,]
            send_mail(subject,message,email_from,rec_list)
            messages.success(request,"user registered successfully")
            return redirect('/')
    return render(request,"register.html")

def login_user(request):
    if request.method=='POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request,username=username,password=password)
        if user is not None:
            login(request, user)
            return redirect('/')
            

        else:
            messages.warning(request,"invalid credentials")
            return redirect('login')
    return render(request,'login.html')


def logout_user(request):
    logout(request)
    return redirect('/')


def reset_password(request):
    if request.method =='POST':
        newpass = request.POST.get('newpassword')
        u = User.objects.get(username=request.user.username)
        u.set_password(newpass)
        u.save()
        messages.success(request,"Password has been changed")
        return redirect('/')
    return render(request,'reset_password.html')

import uuid
def ForgetPassword(request):
    try:
        if request.method == 'POST':
            username = request.POST.get('username')

            if not User.objects.filter(username=username).first():
                messages.warning(request,'No usr found with this username')
                return redirect('/forget_password/')

                user_obj = User.objects.get(username=username)
                token = str(uuid.uuid4())
                send_forget_password_mail(user_obj, token)





    except Exception as e:
        print(e)
    return render(request,'forget_password.html')

# def services(request):
#     return HttpResponse("this is services page")

# def contacts(request):
#     return HttpResponse("this is contacts page")